module Main where
and :: Bool -> Bool -> Bool
and True True = True
and _ _ = False