--last_list ls=last(ls)

--last' :: [a] -> Maybe a
--last' [] = Nothing
--last' [x] = Just x
--last' (x:xs) = last' xs
revhead ks = head(reverse ks)

