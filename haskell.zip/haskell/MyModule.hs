module MyModule where
not' :: Bool -> Bool
not' False = True
not' True = False

-- Input Format: not' True
-- Expected Output False