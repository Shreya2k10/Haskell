not :: Bool -> Bool
not False = True
not True = False