theAnswer::[Integer]->Bool
theAnswer (xs) = all (==42) xs
join ys [] = ys
join ys (z:zs) = z:(join ys zs)
checkA xs ys = theAnswer xs && theAnswer ys
checkB xs ys = theAnswer (join xs ys)

