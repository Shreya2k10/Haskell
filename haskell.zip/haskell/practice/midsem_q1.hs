import Data.List (minimumBy)
import Data.Ord (comparing)

minpt :: (Int -> Int) -> Int -> Int -> Int
minpt f a b
    | a > b = error "Invalid range"
    | otherwise = fst $ minimumBy (comparing snd) [(x, f x) | x <- [a..b]]
