type Var = String
type Fun = String

data Term = V Var | Gnode Fun [Term] deriving (Show, Eq)

type Substitution = [(Var, Term)]

unify :: (Term, Term) -> Substitution
unify (t1, t2) = unify' [(t1, t2)] []

unify' :: [(Term, Term)] -> Substitution -> Substitution
unify' [] s = s
unify' ((V x, V y):ts) s | x == y = unify' ts s
unify' ((V x, t):ts) s = unify' (substitute x t ts) ((x, t):s)
unify' ((t, V x):ts) s = unify' ((V x, t):ts) s
unify' ((Gnode f1 ts1, Gnode f2 ts2):ts) s | f1 == f2 =
    unify' (zip ts1 ts2 ++ ts) s
unify' _ _ = error "MGU not possible"

substitute :: Var -> Term -> [(Term, Term)] -> [(Term, Term)]
substitute x t ts =
    [(substitute' x t t1, substitute' x t t2) | (t1, t2) <- ts]

substitute' :: Var -> Term -> Term -> Term
substitute' x t (V y) | x == y = t
substitute' x t (Gnode f ts) = Gnode f [substitute'' x t ti | ti <- ts]
substitute' _ _ ti = ti

substitute'' :: Var -> Term -> Term -> Term
substitute'' x t (V y) | x == y = t
substitute'' x t ti = ti
