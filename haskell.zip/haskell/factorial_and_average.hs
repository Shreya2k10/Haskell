take_n n1 n2 = take 1 [n1..n2]
fact n = product[1..n]

-- average ns = sum ns `div` length ns
average ns = div (sum ns) (length ns)