data Expr = I String | Add Expr Expr | Sub Expr Expr | IF BExpr Expr Expr | PP String
data BExpr = GT Expr Expr | NOT BExpr

type State = (String -> Int, Int, Int)

newtype StateMonad a = StateMonad { runState :: State -> (a, State) }

instance Functor StateMonad where
  fmap f m = StateMonad $ \s ->
    let (a, s') = runState m s
    in (f a, s')

instance Applicative StateMonad where
  pure a = StateMonad $ \s -> (a, s)
  mf <*> ma = StateMonad $ \s ->
    let (f, s') = runState mf s
        (a, s'') = runState ma s'
    in (f a, s'')

instance Monad StateMonad where
  ma >>= f = StateMonad $ \s ->
    let (a, s') = runState ma s
        (b, s'') = runState (f a) s'
    in (b, s'')

get :: StateMonad State
get = StateMonad $ \s -> (s, s)

put :: State -> StateMonad ()
put s = StateMonad $ \_ -> ((), s)

modify :: (State -> State) -> StateMonad ()
modify f = StateMonad $ \s -> ((), f s)

eval :: Expr -> StateMonad Int
eval (I v) = do
  (env, adds, subs) <- get
  let val = env v
  put (env, adds, subs)
  return val
eval (Add e1 e2) = do
  (env, adds, subs) <- get
  val1 <- eval e1
  val2 <- eval e2
  (env', adds', subs') <- get
  put (env', adds' + 1, subs')
  return (val1 + val2)
eval (Sub e1 e2) = do
  (env, adds, subs) <- get
  val1 <- eval e1
  val2 <- eval e2
  (env', adds', subs') <- get
  put (env', adds', subs' + 1)
  return (val1 - val2)
eval (IF b e1 e2) = do
  (env, adds, subs) <- get
  let cond = evalB b
  put (env, adds, subs)
  if cond then eval e1 else eval e2
eval (PP v) = do
  (env, adds, subs) <- get
  let val = env v
  put (env, adds, subs)
  modify (\(env', adds', subs') -> (env', adds' + 1, subs'))
  return (val + 1)

evalB :: BExpr -> Bool
evalB (NOT b) = not (evalB b)
