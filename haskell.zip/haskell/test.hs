double x = x+x

quadruple x = double(double x)

