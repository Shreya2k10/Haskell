data BTree a = Node (BTree a) a (BTree a) | Null deriving Show

hd :: BTree (a,a) -> (a,a)

hd Null = (0, 0)
hd (Node left _ right) =
    let (hl, dl) = hd left
        (hr, dr) = hd right
        h = 1 + max hl hr
        d = max (max dl dr) (hl + hr + 1)
    in (h, d)

dia :: BTree a -> Int

dia Null = 0
dia (Node l _ r) =
    let
        (hl, dl) = hd l
        (hr, dr) = hd r
    in max (max dl dr) (hl + hr + 1)


singleNodeTree :: BTree Int
singleNodeTree = Node Null 1 Null

emptyTree :: BTree Int
emptyTree = Null

leftHeavyTree :: BTree Int
leftHeavyTree = Node (Node (Node Null 1 Null) 2 Null) 3 Null

rightHeavyTree :: BTree Int
rightHeavyTree = Node Null 1 (Node Null 2 (Node Null 3 Null))

unbalancedTree :: BTree Int
unbalancedTree = Node (Node (Node Null 1 Null) 2 (Node Null 3 Null)) 4 (Node Null 5 (Node Null 6 (Node Null 7 Null)))

main :: IO ()
main = do
    let diameter1 = dia singleNodeTree
    putStrLn ("The diameter of the tree is " ++ show diameter1)
    --expected output: 1
    let diameter2 = dia emptyTree
    putStrLn ("The diameter of the tree is " ++ show diameter2)
    --expected output: 0
    let diameter3 = dia leftHeavyTree
    putStrLn ("The diameter of the tree is " ++ show diameter3)
    --expected output: 3
    let diameter4 = dia rightHeavyTree
    putStrLn ("The diameter of the tree is " ++ show diameter4)
    --expected output: 3
    let diameter5 = dia unbalancedTree
    putStrLn ("The diameter of the tree is " ++ show diameter5)
    --expected output: 7

{-tree diagram:
        4 (7)
       / \
      /   \
     /     \
    2 (3)   5 (2)
   / \       \
  1 (1)      6 (1)
             /
            7 (1)
-}