-- module Main where
import Data.Tree

data Btree a = Bnode (Btree a) (Btree a) | Leaf a

-- Function to convert a general tree (Data.Tree) to your custom Binary Tree (Btree)
g2b :: Tree Char -> Btree Char
g2b (Node x []) = Leaf x
g2b (Node x xs) = Bnode (g2b (head xs)) (g2b (Node x (tail xs)))

-- Function to convert your custom Binary Tree (Btree) to a list of general trees (Data.Tree)
b2gs :: Btree Char -> [Tree Char]
b2gs (Leaf x) = [Node x []]
b2gs (Bnode l r) = b2gs l ++ b2gs r

-- Function to convert your custom Binary Tree (Btree) to a general tree (Data.Tree)
b2g :: Btree Char -> Tree Char
b2g (Leaf x) = Node x []
b2g (Bnode l r) = Node (rootLabel (b2g l)) (b2gs r)

-- Examples
example1 = g2b (Node ' ' [])
example2 = g2b (Node 'a' [])
example3 = g2b (Node 'f' [Node 'g' [], Node 'h' [], Node 'i' []])
example4 = g2b (Node 'f' [Node 'g' [Node 'x' []], Node 'h' [Node 'y' []], Node 'i' [Node 'z' []]])
example5 = b2gs (Leaf ' ')
example6 = b2gs (Leaf 'a')
example7 = b2gs (Bnode (Bnode (Bnode (Leaf 'a') (Leaf 'b')) (Bnode (Leaf 'c') (Leaf 'd'))) (Bnode (Bnode (Leaf 'e') (Leaf 'f')) (Bnode (Leaf 'g') (Leaf 'h'))))
example8 = b2gs (Bnode (Leaf 'a') (Bnode (Leaf 'b') (Bnode (Leaf 'c') (Leaf 'd'))))
example9 = b2gs (Bnode (Bnode (Bnode (Leaf 'a') (Leaf 'b')) (Bnode (Leaf 'c') (Leaf 'd'))) (Bnode (Bnode (Leaf 'e') (Leaf 'f')) (Bnode (Leaf 'g') (Leaf 'h'))))
example10 = g2b (Node 'f' [Node 'g' [Node 'x' []], Node 'h' [Node 'l' []], Node '5' [Node 'm' [Node 'n' []]]])


--example11 = b2g (Bnode (Bnode (Bnode (Leaf 'f') (Bnode (Bnode (Leaf 'g') (Leaf 'x')) (Leaf '1'))) (Bnode (Leaf 'h') (Leaf '1'))) (Leaf '5'))


main :: IO ()
main = do
    
    putStrLn "Example 1:"
    print example1
    putStrLn "\nExample 2:"
    print example2
    putStrLn "\nExample 3:"
    print example3
    putStrLn "\nExample 4:"
    print example4
    putStrLn "\nExample 5:"
    print example5
    putStrLn "\nExample 6:"
    print example6
    putStrLn "\nExample 7:"
    print example7
    putStrLn "\nExample 8:"
    print example8
    putStrLn "\nExample 9:"
    print example9
    putStrLn "\nExample 10:"
    print example10
