import Data.List (intersperse)

data Gtree = Node String [Gtree] | Leaf String
data Btree = BNode String Btree Btree | BLeaf String

g2b :: Gtree -> Btree
g2b (Leaf s) = BLeaf s
g2b (Node s []) = BLeaf ""
g2b (Node s gs) = BNode s (g2b $ head gs) (g2bList $ tail gs)
    where g2bList [] = BLeaf ""
          g2bList [x] = g2b x
          g2bList xs = BNode "" (g2b $ head xs) (g2bList $ tail xs)

b2g :: Btree -> Gtree
b2g (BLeaf s) = Leaf s
b2g (BNode s l r) = Node s (map b2g [l, r])

instance Show Gtree where
    show (Leaf s) = "GNode \"" ++ s ++ "\" []"
    show (Node s []) = "GNode \"" ++ s ++ "\" []"
    show (Node s gs) = "GNode \"" ++ s ++ "\" [" ++ concat (intersperse ", " $ map show gs) ++ "]"

instance Show Btree where
    show (BLeaf "") = "BLeaf \"\""
    show (BLeaf s) = "BLeaf \"" ++ s ++ "\""
    show (BNode s l r) = "BNode \"" ++ s ++ "\" (" ++ show l ++ ") (" ++ show r ++ ")"

main :: IO ()
main = do
    putStrLn "Boundary case 1: An empty binary tree"
    print $ b2g $ BLeaf ""
    --expected output: GNode "" []
    putStrLn "Boundary case 2: A binary tree with only one node"
    print $ b2g $ BLeaf "x"
    --expected output: GNode "x" []
    putStrLn "Boundary case 3: A binary tree with two nodes"
    print $ b2g $ BNode "f" (BLeaf "x") (BLeaf "y")
    --expected output: GNode "f" [GNode "x" [], GNode "y" []]
    putStrLn "Boundary case 4: A binary tree with three nodes in a level"
    print $ b2g $ BNode "f" (BNode "g" (BLeaf "x") (BLeaf "y")) (BLeaf "z")
    --expected output: GNode "f" [GNode "g" [GNode "x" [], GNode "y" []], GNode "z" []]

    putStrLn "Boundary case 5: Full Binary tree"
    print $ b2g $ BNode "f" (BNode "g" (BLeaf "x") (BLeaf "y")) (BNode "h" (BLeaf "z") (BLeaf "w"))
    --expected output: GNode "f" [GNode "g" [GNode "x" [], GNode "y" []], GNode "h" [GNode "z" [], GNode "w" []]]


    putStrLn "\nBoundary case 1: An empty general tree"
    print $ g2b $ Leaf ""
    --expected output: Output: BLeaf ""

    putStrLn "\nBoundary case 2:  A general tree with only one node"
    print $ g2b $ Leaf "x"
    -- expected output: BNode Leaf 'x'


    putStrLn "\nBoundary case 3: A general tree with two nodes"
    print $ g2b $ Node "f" [Leaf "x", Leaf "y"]
    -- expected output:: (BLeaf "x") (BLeaf "y")

    putStrLn "\nBoundary case 4: A general unbalanced tree with three nodes"
    print $ g2b $ Node "f" [Node "g" [Leaf "x", Leaf "y"], Leaf "z"]
    -- expected output: (BNode "g" (BLeaf "x") (BLeaf "y")) (BLeaf "z")

    putStrLn "\nBoundary case 5: A full binary tree "
    print $ g2b $ Node "f" [Node "g" [Leaf "x", Leaf "y"], Node"h"[Leaf"z", Leaf"w"]]
    -- expected output: BNode "f" (BNode "g" (BLeaf "x") (BLeaf "y")) (BNode "h" (BLeaf "z") (BLeaf "w"))


-- At first, type  ghci q3.hs in directory where my haskall codes are saved
-- I wrote these codes as per ghci, version 8.6.5
-- To get output of all inputs I've specified just type "main"
-- To ask function g2b or b2g convert function of your choice in desired format on terminal type "let gt (or nt)= (function specifications)" in next line type g2b gt, same format will be used if you want to call function b2g