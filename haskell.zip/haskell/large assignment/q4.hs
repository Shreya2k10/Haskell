data HTree a = Null | Fork a (HTree a) (HTree a)

levels :: [a] -> [[a]]
levels [] = []
levels [x] = [[x]]
levels xs = ys : levels zs
  where
    (ys, zs) = split xs
    split [] = ([], [])
    split [x] = ([x], [])
    split (x:y:xs) = (x:ys, zs)
      where
        (ys, zs) = split xs









addLayer :: [a] -> [HTree a] -> [HTree a]
addLayer [] ts = ts
addLayer _ [] = []
addLayer (x:xs) (t1:t2:ts) = Fork x t1 t2 : addLayer xs ts
addLayer (x:xs) [t] = Fork x t Null : addLayer xs []

{-
mkHTrees :: Ord a => [[a]] -> [HTree a]
mkHTrees = foldr addLayer [Null]

mkHTree :: Ord a => [a] -> HTree a
mkHTree xs = head $ mkHTrees $ levels xs

heapify :: Ord a => HTree a -> HTree a
heapify Null = Null
heapify (Fork x ht1 ht2) = sift x (heapify ht1) (heapify ht2)

sift :: Ord a => a -> HTree a -> HTree a -> HTree a
sift x Null Null = Fork x Null Null
sift x (Fork y l r) Null
  | x < y     = Fork y (sift x l r) Null
  | otherwise = Fork x (sift y l r) Null
sift x Null (Fork y l r)
  | x < y     = Fork y (sift x l r) Null
  | otherwise = Fork x (sift y l r) Null
sift x t1@(Fork y l1 r1) t2@(Fork z l2 r2)
  | x < y && x < z   = Fork y (sift x l1 r1) t2
  | y < z            = Fork y (sift x l1 r1) (sift z l2 r2)
  | otherwise        = Fork z (sift x l2 r2) (sift y r1 r2)

mkHeap :: Ord a => [a] -> HTree a
mkHeap = heapify . mkHTree
-}