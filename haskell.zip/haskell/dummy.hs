-- Define your input data as constants or variables
myList :: [Int]
myList = [1, 2, 3, 4, 5]

-- Define your Haskell program
reverseList :: [a] -> [a]
reverseList [] = []
reverseList (x:xs) = reverseList xs ++ [x]

extractHead :: [a] -> a
extractHead [] = error "Cannot extract head from an empty list."
extractHead (x:_) = x

main :: IO ()
main = do
    let reversedList = reverseList myList
    let headElement = extractHead reversedList
    print headElement
