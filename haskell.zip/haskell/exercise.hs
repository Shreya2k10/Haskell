a = 10
xs = [1,2,3,4,5]
n = a `div` length xs
